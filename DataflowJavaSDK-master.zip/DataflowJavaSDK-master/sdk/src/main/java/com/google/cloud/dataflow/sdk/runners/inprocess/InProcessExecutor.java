/*
 * Copyright (C) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.google.cloud.dataflow.sdk.runners.inprocess;

import com.google.cloud.dataflow.sdk.runners.inprocess.InProcessPipelineRunner.CommittedBundle;
import com.google.cloud.dataflow.sdk.transforms.AppliedPTransform;
import com.google.cloud.dataflow.sdk.transforms.PTransform;

import java.util.Collection;

/**
 * An executor that schedules and executes {@link AppliedPTransform AppliedPTransforms} for both
 * source and intermediate {@link PTransform PTransforms}.
 */
interface InProcessExecutor {
  /**
   * Starts this executor. The provided collection is the collection of root transforms to
   * initially schedule.
   *
   * @param rootTransforms
   */
  void start(Collection<AppliedPTransform<?, ?, ?>> rootTransforms);

  /**
   * Blocks until the job being executed enters a terminal state. A job is completed after all
   * root {@link AppliedPTransform AppliedPTransforms} have completed, and all
   * {@link CommittedBundle Bundles} have been consumed. Jobs may also terminate abnormally.
   *
   * @throws Throwable whenever an executor thread throws anything, transfers the throwable to the
   *                   waiting thread and rethrows it
   */
  void awaitCompletion() throws Throwable;
}
