# SDK Javadoc

This directory contains package-info files for external javadoc we would like
our javadoc to link to using `-linkoffline`.
