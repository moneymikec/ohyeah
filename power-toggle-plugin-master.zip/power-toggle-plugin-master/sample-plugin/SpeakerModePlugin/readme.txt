Speaker mode plugin

When active automatically switches all calls to speaker mode.
This project exposes no UI, and is solely controlled by the PowerToggles app.
